import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import './App.css';
import { Provider } from "react-redux";
import PostMessages from "./components/PostMessages";
import { store } from "./actions/store";
import { Container, AppBar, Typography } from "@material-ui/core";
import ButterToast,{ POS_RIGHT,POS_TOP } from "butter-toast";
import { NavLink } from 'react-router-dom';


function App() {
  return (<div>

    <nav class="navbar navbar-expand-lg navbar-light bg-primary">
  <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        < NavLink to="/home" class="nav-link active">Home</NavLink>
      </li>
      <li class="nav-item active">
        < NavLink to="/alljob1" class="nav-link active">All Jobs</NavLink>
      </li>
      <li class="nav-item active">
        < NavLink to="/companies" class="nav-link active">Companies</NavLink>
      </li>
      <li class="nav-item active">
        < NavLink to="/logout2" class="nav-link active">Logout</NavLink>
      </li>

    </ul>

  </div>
</nav>
    <Provider store={store}>
      <Container maxWidth="lg">
        <AppBar position="static" color="inherit">
          <Typography
            variant="h5"
            align="center">
              
Admin | Employer Post Jobs          </Typography>
        </AppBar>
        <PostMessages />
        <ButterToast position={{vertical:POS_TOP,horizontal:POS_RIGHT}}/>
      </Container>
    </Provider>
    </div>
  );
}

export default App;