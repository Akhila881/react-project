import React from 'react';
import { NavLink } from 'react-router-dom';
import profile from "../images/profile.png";

class UserComponents extends React.Component{
    render(){
        return(
            <div><nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              < NavLink to="/home1" class="nav-link active">Home</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/alljob" class="nav-link active">All Jobs</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/companies" class="nav-link active">Companies</NavLink>
            </li>
            
  
          </ul>
  
        </div>
      </nav>
  
            <nav class="nav flex-column">
            < NavLink to ="/usercom"  class="nav-link active">  <img src={profile} width="100" height="100" padding="60" /></ NavLink>
          
  < NavLink to ="/applied"  class="nav-link active">Applied Jobs</NavLink>
  < NavLink to ="/saved"  class="nav-link active">Saved Jobs</NavLink>
  < NavLink to ="/profile"  class="nav-link active">Profile Details</NavLink>

</nav>
</div>
        );
    }
}
export default UserComponents;
