import React, { Component } from 'react';
import HotjobComponent from "./HotjobComponent";
import { NavLink } from 'react-router-dom';
import SearchBar from "material-ui-search-bar";
import { ArrowRight } from '@material-ui/icons';
import amazon from "../images/amazon.png";
import microsoft from "../images/microsoft.jpg";
import google from "../images/google.jpeg";
import paypal from "../images/paypal.jpg";
import cocacola from "../images/cocacola.png";
import apple from "../images/apple.png";
import samsung from "../images/samsung.png";
import profile2 from "../images/profile2.png";
import HotjobComponent2 from './HotjobComponent2';

class HomepageComponent2 extends React.Component {

  constructor() {
    super();
    this.location = "";
    this.skills = "";
    this.state =
    {
      searchData: "",
      err: ''
    }
  }
  getRelavantJobs(location, skills) {
    console.log(skills);
    console.log(location);
    if (!skills && !location) {
        this.setState({ searchData: '' });
    } else {
        fetch("http://localhost:4000/postMessages/searchJobs?location=" + location + "&skills=" + skills).then((data) => {
            data.json().then((res) => {
                console.warn("res", res);
                console.log(res);
                console.log('heree')
                this.setState({ searchData: res });
            });
        });
    }
  
  }
  login(e) {
    e.preventDefault();
    var email = e.target.elements.email.value;
    var password = e.target.elements.password.value;
    if (email === 'thejeshreddy98@gmail.com' && password === '12345') {
      this.props.history.push('/userlogin');

    } else {
      this.setState({
        err: 'Invalid'
      });
    }
  }

  render() {
    let format = {
      color: "red"
    };
    const my = {
      width: "20%",
      padding: "10px 20px",
      margin: "60px 7px",
      boxSizing: "border-box",
      border: "2px solid #6495ED",
      borderRadius: "4px"
    }


    return (<div> <nav class="navbar navbar-expand-lg navbar-light bg-primary">
      <a class="navbar-brand" href="#"><h1>Online Job</h1> </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
         
          <li class="nav-item active">
            < NavLink to="/alljob" class="nav-link active">All Jobs</NavLink>
          </li>
          <li class="nav-item active">
            < NavLink to="/companies" class="nav-link active">Companies</NavLink>
          </li>
          <li class="nav-item active">
              < NavLink to="/logout" class="nav-link active">Logout</NavLink>
            </li>

        </ul>
        <div class="dropdown">
  <button class="dropbtn">< NavLink to="/applied" class="nav-link active">           
   <img src={profile2} width="25" height="25"  />
</NavLink>
 </button>
  
</div>
      </div>
    </nav>
    <div  className="bglogo">
   



      <div>
      <form className="loginForm" onSubmit={this.handleSubmit} style={{ marginRight: "0px" }} >
               
                
<div style={{ marginRight: "0px" }}>

                


               <div className="form-group " >

                 <label><span className="fa fa-user" style={{ fontSize: "28px" }}></span> </label>

                 <div className="col-sm-12">


                   <input disabled type="text"
                     className="form-control" placeholder="Username"
                     name="username" onChange={this.handleChange} required
                   />
                 </div>
               </div>

               <div className="form-group" >
                 <label><span className="fa fa-lock" style={{ fontSize: "28px" }}></span> </label>

                 <div className="col-sm-12">
                   <input disabled type="password"
                     className="form-control" placeholder="Password"
                     name="password" onChange={this.handleChange} required
                   />
                 </div>
               </div>


              
               <div className="col-sm-12" style={{ marginLeft: "0px" }}>

                
                   {this.state.message !== '' && <div className={`text text-${this.state.textStyle}`}>{this.state.message}</div>}<br />
                   
                   <button disabled type="submit" className="form-control" >Submit</button>
               

             </div>
             </div>
             </form>

             <div className="row">
                    <div className="col">
                        <input type="text" placeholder="Search By Location" style={my}
                            onChange={(event) => { this.location = event.target.value; this.getRelavantJobs(this.location, this.skills) }} />
                        <input type="text" placeholder="Search by Skills" style={my}
                            onChange={(event) => { this.skills = event.target.value; this.getRelavantJobs(this.location, this.skills) }}
                        />
                        </div>
                </div>
                <div>
                    {
                        this.state.searchData ?
                            <div>
                                {
                                    this.state.searchData.map((item) =>
                                        <div>
                                            <div >

                                                <div class="card-body">
                                                    <h5 class="card-title">{item.companyname}</h5>

                                                    <p class="card-text">Location: {item.location}</p>
                                                    <p class="card-text">Skills Required: {item.skills}</p>
                                                    < NavLink to="/alljob" class="nav-link active"> <button type="submit" class="btn btn-primary"
                                                      
                                                      disabled={this.state.disabled} >  Apply </button></ NavLink>
                                                </div>
                                            </div>
                                        </div>)

                                }
                            </div>
                            : ""

                    }
                </div>


       
        <h4 >Hot Hires</h4>
        <div >
          < img src={amazon} width="200" height="200" padding="60" />
          <img src={microsoft} width="200" height="200" padding="60" />
          <img src={google} width="200" height="200" padding="60" />
        
          <img src={paypal} width="200" height="200" padding="60" />
        
          <img src={samsung} width="200" height="200" padding="60" />
  <img src={cocacola} width="200" height="200" padding="60" />
          <img src={apple} width="200" height="200" padding="60" />

        </div>
        <HotjobComponent2 />
        <h4>Career tips</h4>
<p><li>A break helps. ...</li>       
<li>  Seek help building your resume. ...</li>
</p><br/>
<p><li>List your strengths. ...</li>
<li>Online job boards. ...</li>
</p><br/>
<p><li>Make the most of your networking skills. ...
</li>
<li>Research your employer. ...
</li>
</p><br/>
<p><li>Sport a smile. ...
</li>
<li>Always look presentable. ...
</li>
</p><br/>

      </div></div>
    </div>
    );
  }
}
export default HomepageComponent2;