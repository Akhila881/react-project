import React from 'react';
import { Component } from 'react';
import axios from 'axios';
import { NavLink } from 'react-router-dom';


class EmploymentComponent extends Component{

    state = {
        
        currentEmployer: '',
        designation :'',
        jobDescription1:'',
        experience1: '',
        previousEmployer: '',
        jobDescription2: '',
        experience2: '',
        
    }

    handleChange = ({ target }) => {
        const { name, value } = target;
        this.setState({ [name]: value });
      };

      submit = (e) => {
          e.preventDefault();
          const payload = {
            currentEmployer:this.state.currentEmployer,
            designation:this.state.designation,
            jobDescription1:this.state.jobDescription1,
            experience1:this.state.experience1,
            previousEmployer:this.state.previousEmployer,
            jobDescription2:this.state.jobDescription2,
            experience2:this.state.experience2,
    
        };
    
    
        axios({
          url: 'http://localhost:4000/employmentMessages',
          method: 'POST',
          data: payload
        })
          .then(() => {
            console.log('Data has been sent to the server');
           
          })
          .catch(() => {
            console.log('Internal server error');
          });;

          alert("Please wait Taking to you next page");
this.props.history.push('/education');
      }
    render(){
        const mystyle = {
            width: "30%",
            padding: "10px",
            margin: "10px",
            boxSizing: "border-box",
            border: "2px solid #6495ED",
            borderRadius: "4px"
        }
        const mybtn = {

            width: "20%",
            margin: "10px"
        }

        const header2 = {
            color: "Tomato",
            marginTop: "50px",
            textDecoration: "underline"
        }
        return (<div><nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              < NavLink to="/home" class="nav-link active">Home</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/alljob1" class="nav-link active">All Jobs</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/companies" class="nav-link active">Companies</NavLink>
            </li>
            
  
          </ul>
  
        </div>
      </nav>
            <div>
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <li class="nav-item">
          <NavLink to="/personal" class="nav-link " id="pills-home-tab" data-toggle="pill" role="tab" aria-controls="pills-home" aria-selected="true">Personal</NavLink>
        </li>
        <li class="nav-item">
          <NavLink to="/employment" class="nav-link active" id="pills-profile-tab" data-toggle="pill"  role="tab" aria-controls="pills-profile" aria-selected="false">Emploment</NavLink>
        </li>
        <li class="nav-item">
          <NavLink to="/education" class="nav-link disabled" id="pills-contact-tab" data-toggle="pill"  role="tab" aria-controls="pills-contact" aria-selected="false">Education</NavLink>
        </li>
      </ul>
     
      <div className="container">
            

            
            <form onSubmit={this.submit} method="POST">
           

            <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text"  placeholder="Enter Current Employer" class="form-control" id="college" 
                        onChange={this.handleChange} name="currentEmployer" style={{ height: '90%', width: '40%' }}
                        value={this.state.currentEmployer} required />
                </div>
</div>

<div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <textarea placeholder="enter Designation"  class="form-control" id="email" 
                        onChange={this.handleChange} name="designation" style={{ height: '90%', width: '40%' }}
                        value={ this.state.designation} required/>
                </div>
</div>

<div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="Job Description" class="form-control" id="email" 
                        onChange={this.handleChange} name="jobDescription1"style={{ height: '90%', width: '40%' }}
                        value={this.state.jobDescription1} required/>
                   </div>
                </div>
                <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="Experience" class="form-control" id="email" 
                        onChange={this.handleChange} name="experience1" style={{ height: '90%', width: '40%' }}
                        value={this.state.experience1} required/>
                   
                </div></div>
                <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="Previous Employer" class="form-control" id="email" 
                        onChange={this.handleChange} name="previousEmployer" style={{ height: '90%', width: '40%' }}
                        value={this.state.previousEmployer} required/>
                   
                </div></div>
                <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="Job Description" class="form-control" id="email" 
                        onChange={this.handleChange} name="jobDescription2" style={{ height: '90%', width: '40%' }}
                        value={this.state.jobDescription2} required/>
                   
                </div></div>
                <div className="form-group" style={{ display: "flex" }} >
              <label className="control-label col-sm-2 "> </label>
              <div className="col-sm-11">
                    <input type="text" placeholder="experience" class="form-control" id="email" 
                        onChange={this.handleChange} name="experience2"style={{ height: '90%', width: '40%' }}
                        value={this.state.experience2} required/>
                   
                </div></div>

               



                



                <button type="submit" class="btn btn-primary mr-2"     
                 disabled={this.state.disabled}>Next</button>

            </form>
        </div>
    </div>
</div>
);
    }
}


export default EmploymentComponent;