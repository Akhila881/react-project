import React, { Component } from "react";
import axios from 'axios';
import {NavLink} from 'react-router-dom';
import { hydrate } from "react-dom";

class AlljobComponent extends Component {

    state = {
        posts: [],
        appliedJobs:[],
        savedJobs:[]
    };

    savedSubmit = (companyname,jtitle,role,location,salaryrange,responsibility) =>{
        
        console.log(companyname);
    const payload = {
        savedJobs:"Company Name : "+ companyname + "\n"+
        "Title : " +jtitle+"\n"+
        "Role : "+role+"\n"+
         " Location: " +location +"\n"+
          "Salary Range : "+salaryrange+"\n"+
          " Responsibility: " +responsibility
    };
    axios({
        url: 'http://localhost:4000/savedMessageController/savedJobs',
        method: 'POST',
       data : payload
    })
    .then(() => {
        //this.setState({ appliedJobs: payload});
        console.log('Data has been sent to the server');

    })
    .catch(() => {
        console.log('Internal server error');
    });;
    
    alert("Saved Successfully");
}




    appliedSubmit = (companyname,jtitle,role,location,salaryrange,responsibility) =>{
        
            console.log(companyname);
        const payload = {
          appliedJobs:"Company Name : "+ companyname 
          + "Title : " +jtitle 
          +"Role : "+role 
          + " Location: " +location 
          + "Salary Range : "+salaryrange 
          +" Responsibility: " +responsibility
        };
        axios({
            url: 'http://localhost:4000/appliedMessageController/appliedJobs',
            method: 'POST',
           data : payload
        })
        .then(() => {
            //this.setState({ appliedJobs: payload});
            console.log('Data has been sent to the server');

        })
        .catch(() => {
            console.log('Internal server error');
        });;
        
        alert("Applied Successfully");
    }


    componentDidMount = () => {
        this.getBlogPost();
    };

    getBlogPost = () => {
        axios.get('http://localhost:4000/postMessages')
            .then((response) => {
                const data = response.data;
                this.setState({ posts: data });
                console.log('Data has been received!!');
            })
            .catch(() => {
                alert('Error retrieving data!!!');
            });
    }

    displayBlogPost = (posts) => {

        if (!posts.length) return null;
        

        return posts.map((post, index) => (
            <div>
                
                 
                <div key={index} className="blog-post__display">

                <h4>Company name : {post.companyname}</h4>
                <p>title : {post.jtitle}</p>
                <p>Role : {post.role}</p>
                <p>Location : {post.location}</p>
        <p>Salary Range :{post.salaryrange}</p>
        <p>Responsibility :{post.responsibility}</p>

                            <div>
                               
                                <button type="submit" class="btn btn-primary" 
                            disabled={this.state.disabled} 
                            onClick={() => this.appliedSubmit(
                              post.companyname,post.jtitle,post.role,post.location,post.salaryrange,post.responsibility)}>Apply</button>
                                
                            </div>
                            <br></br>
                            <div></div>
                            <button type="submit" class="btn btn-primary" 
                            onClick={() => this.savedSubmit(post.companyname,post.jtitle,post.role,post.location,post.salaryrange,post.responsibility)}
                            disabled={this.state.disabled}>Save</button>
                        </div>


                    </div>

                
             
            

        ));
    };

    render() {
       
        return (<div >
          <div><nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <a class="navbar-brand" href="#"><h1>Online Job </h1></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              < NavLink to="/home1" class="nav-link active">Home</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/alljob" class="nav-link active">All Jobs</NavLink>
            </li>
            <li class="nav-item active">
              < NavLink to="/companies" class="nav-link active">Companies</NavLink>
            </li>
            
  
          </ul>
  
        </div>
      </nav>
  
            <div className="blog-post__display" >
                {this.displayBlogPost(this.state.posts)}
                
            </div>
            </div>
            
        </div>);
    }
};


export default AlljobComponent;