import React from "react";

const initialState = {
  name: "",
  email: "",
  password: "",
  mobileno:"",
  nameError: "",
  emailError: "",
  passwordError: "",
  mobilenoError:""
};

export default class ExperiencedComponent extends React.Component {
  state = initialState;

  handleChange = event => {
    const isCheckbox = event.target.type === "checkbox";
    this.setState({
      [event.target.name]: isCheckbox
        ? event.target.checked
        : event.target.value
    });
  };

  validate = () => {
    let nameError = "";
    let emailError = "";
    let mobilenoError="";
    // let passwordError = "";

    if (!this.state.name) {
      nameError = "Name cannot be blank";
    }

    if (!this.state.email.includes("@")) {
      emailError = "invalid email";
    }
    if (!this.state.mobileno) {
        mobilenoError = "Mobile no cannot be blank";
      }

    if (emailError || nameError || mobilenoError) {
      this.setState({ emailError, nameError ,mobilenoError});
      return false;
    }
   
    return true;
  };

  handleSubmit = event => {
    event.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      console.log(this.state);
      // clear form
      this.setState(initialState);
    }
  };

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        
        <div class="form-group">
    <label for="name">Name</label>
    <input type="text" class="form-control" id="name" placeholder="Enter your full name"/>
  
          <div style={{ fontSize: 12, color: "red" }}>
            {this.state.nameError} 
          </div>
        </div>
        <div class="form-group">
    <label for="email">Email</label>
    <input type="email" class="form-control" id="email" placeholder="Enter your email id"/>
          <div style={{ fontSize: 12, color: "red" }}>
            {this.state.emailError} 
          </div>
        </div>
        <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" id="password" placeholder="Password"/>
          
        </div>
        <div class="form-group">
    <label for="mobleno">Mobile No</label>
    <input type="text" class="form-control" id="mobileno" placeholder="Mobile No"/>
          <div style={{ fontSize: 12, color: "red" }}>
            {this.state.mobilenoError}
          </div>
        </div>
        <button type="submit">submit</button>
      </form>
    );
  }
}