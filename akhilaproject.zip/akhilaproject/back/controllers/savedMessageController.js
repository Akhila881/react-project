const express = require('express');

const router = express.Router();

var {BlogPost5} = require('../models/savedMessage');


// Routes
router.get('/savedJobs', (req, res) => {
    BlogPost5.find((err, docs) => {
        if (!err){
            res.send(docs)
        }
        else
         console.log('Error while retrieving all records : ' + JSON.stringify(err, undefined, 2))
    });
});


router.post('/savedJobs',(req,res) => {

    console.log('name: ',req.body);
    const data = req.body;

    const newBlogPost = new BlogPost5(data);

    newBlogPost.save((error) => {
        if (error) {
            res.status(500).json({ msg: 'Sorry, internal server errors' });
            return;
        }
        // BlogPost
        return res.json({
            msg: 'Your data has been saved!!!!!!'
        });
    });
});
module.exports = router;