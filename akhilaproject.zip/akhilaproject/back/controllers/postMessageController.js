const express = require('express')
var router = express.Router()
var ObjectID = require('mongoose').Types.ObjectId


var { PostMessage } = require('../models/postMessage')


router.get('/', (req, res) => {
    PostMessage.find((err, docs) => {
        if (!err) {
            res.send(docs);
        }
        else console.log('Error while retrieving all records : ' + JSON.stringify(err, undefined, 2))
    })
})

router.post('/', (req, res) => {
    var newRecord = new PostMessage({
        jid: req.body.jid,
        jtitle: req.body.jtitle,
        role: req.body.role,
        responsibility: req.body.responsibility,
        companyname: req.body.companyname,
        experience: req.body.experience,
        salaryrange: req.body.salaryrange,
        noofpositions: req.body.noofpositions,
        location: req.body.location,
        skills: req.body.skills,
        degree: req.body.degree,
        companyinfo: req.body.companyinfo,
        employeetype: req.body.employeetype,
        industrytype: req.body.industrytype,
        searchkeyword:req.body.searchkeyword,
        jobdescription :req.body.jobdescription





    })

    newRecord.save((err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while creating new record : ' + JSON.stringify(err, undefined, 2))
    })
})

router.put('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id : ' + req.params.id)

    var updatedRecord = {
        jid: req.body.jid,
        jtitle: req.body.jtitle,
        role: req.body.role,
        responsibility: req.body.responsibility,
        companyname: req.body.companyname,
        experience: req.body.experience,
        salaryrange: req.body.salaryrange,
        noofpositions: req.body.noofpositions,
        location: req.body.location,
        skills: req.body.skills,
        degree: req.body.degree,
        companyinfo: req.body.companyinfo,
        employeetype: req.body.employeetype,
        industrytype: req.body.industrytype,
        searchkeyword:req.body.searchkeyword,
        jobdescription :req.body.jobdescription
    }

    PostMessage.findByIdAndUpdate(req.params.id, { $set: updatedRecord },{new:true}, (err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while updating a record : ' + JSON.stringify(err, undefined, 2))
    })
})

router.delete('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id : ' + req.params.id)

    PostMessage.findByIdAndRemove(req.params.id, (err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while deleting a record : ' + JSON.stringify(err, undefined, 2))
    })
})
router.get('/searchJobs',async(req,res) => {

    //const jobLocationField = "Hyderabad";
    const jobLocationField = req.query.location ?  req.query.location : "";
    const jobSkillsField = req.query.skills ?  req.query.skills : "";
    console.log(jobLocationField);
    console.log(jobSkillsField);
    
   //const jobSkillsField ="";
    PostMessage.find(
        {location:{$regex: jobLocationField,$options: '$i'},
        skills:{$regex: jobSkillsField,$options: '$i'}}
        )
    .then(data => {
        res.send(data);
    })

   
})


module.exports = router