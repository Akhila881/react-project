const mongoose = require('mongoose')

var PostMessage = mongoose.model('PostMessage',
{
    jid : {type:String},
    jtitle : {type:String},
    role : {type:String},
    responsibility : {type:String},
    companyname : {type:String},
    experience : {type:String},
    salaryrange : {type:String},
    noofpositions: {type:String},
    location : {type:String},
    skills : {type:String},
    degree : {type:String},
    companyinfo : {type:String},
    employeetype : {type:String},
    industrytype : {type:String},
    searchkeyword : {type:String},
    jobdescription : {type:String}
},'postMessages')

module.exports = { PostMessage}