const mongoose = require('mongoose');

//schema
const BlogPost5 = mongoose.model('BlogPost5', {
    savedJobs:{
        type: String
    }
  

},'SavedJobs');

module.exports =  {BlogPost5};