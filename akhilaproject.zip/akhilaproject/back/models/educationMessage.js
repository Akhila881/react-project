const mongoose = require('mongoose')

var EducationMessage = mongoose.model('EducationMessage',
{
    college : {type:String},
    year : {type:String},
    graduated : {type:String},
    graduateschool : {type:String},
    numberofyears : {type:String},
    skills : {type:String},
    certification : {type:String}
    
},'educationMessages')

module.exports = { EducationMessage}