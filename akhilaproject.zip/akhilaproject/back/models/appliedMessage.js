const mongoose = require('mongoose');

//schema
const BlogPost4 = mongoose.model('BlogPost4', {
    appliedJobs:{
        type: String
    }
  

},'AppliedJobs');

module.exports =  {BlogPost4};